#!/usr/bin/bash
cd ~/futures-hero
python3 -u ./run.py